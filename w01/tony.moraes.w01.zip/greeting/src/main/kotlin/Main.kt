package org.example

fun main(args: Array<String>) {
    println("What is your name?")
    val name = readln()
    println("Hello, $name!")
}
